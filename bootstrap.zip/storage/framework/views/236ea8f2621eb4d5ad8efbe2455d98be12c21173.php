<?php $__env->startSection('content'); ?>
<!-- category add -->
<section class="content-header">
    <h1>
        Category Add
        <small>Preview</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">Category Forms</li>
    </ol>
</section>
<section class="content">
    <div class="row">
    	<div class="col-md-6">

    	    <div class="box box-danger">
    	        <div class="box-header">
    	            <h3 class="box-title">Input Category</h3> <span class="float-right-btn"><a href="<?php echo e(route('admin-category.index')); ?>" class="btn btn-sm btn-success text-white">View Category</a></span>
    	        </div>
    	        <div class="box-body">
    	            <!-- Date dd/mm/yyyy -->
    	            <div class="form-group">
    	                <label>Category Name:</label>
    	                <div class="input-group">
    	                    <div class="input-group-addon">
    	                        <i class="fa fa-list"></i>
    	                    </div>
    	                    <input type="text" class="form-control" name="category_name" />
    	                </div><!-- /.input group -->
    	            </div><!-- /.form group -->

    	            <!-- phone mask -->
    	            <div class="form-group">
    	                <label>Title:</label>
    	                <div class="input-group">
    	                    <div class="input-group-addon">
    	                        <i class="fa fa-eye"></i>
    	                    </div>
    	                    <input type="text" class="form-control" name="category_title" />
    	                </div><!-- /.input group -->
    	            </div><!-- /.form group -->

    	            <!-- IP mask -->
    	            <div class="form-group">
    	                <label>Description:</label>
    	                <div class="input-group">
    	                    <div class="input-group-addon">
    	                        <i class="fa fa-info"></i>
    	                    </div>
    	                    <textarea class="form-control" name="category_description" rows="10"></textarea>
    	                </div><!-- /.input group -->
    	            </div><!-- /.form group -->
    	            <button class="btn btn-success btn-sm float-right-btn text-white" type="button">Submit</button>
    	        </div><!-- /.box-body -->

    	    </div><!-- /.box -->

    	</div><!-- /.col (left) -->
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backendLayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-project\propandas\resources\views/admin/category/category-add.blade.php ENDPATH**/ ?>